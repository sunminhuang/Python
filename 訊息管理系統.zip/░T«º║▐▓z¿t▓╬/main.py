import tkinter as tk
username = "sunmin"
password = "123456"


# 1.登錄
class LoginPage():
    def __init__(self, root_2):
        #創建一個視窗
        self.root = root_2
        self.root.title("成績管理系統")
        #視窗大小
        self.root.geometry('300x150')

        self.username_str_var = tk.StringVar()
        self.password_str_var = tk.StringVar()

        #一個頁面
        self.login_frame = tk.Frame()

        self.login_frame.pack()#設置到頁面
        #排版
        tk.Label(self.login_frame).grid(row = 0, column = 0)
        tk.Label(self.login_frame, text = "帳號: ").grid(row = 1, column = 1)
        tk.Entry(self.login_frame, textvariable = self.username_str_var).grid(row = 1, column = 2)#輸入框
        tk.Label(self.login_frame, text = "密碼: ").grid(row = 2, column =1)
        tk.Entry(self.login_frame, textvariable = self.password_str_var).grid(row = 2, column = 2)#輸入框
        tk.Label(self.login_frame).grid(row = 3, column = 3)



        #按下登錄，獲取用戶訊息，進行驗證
        tk.Button(self.login_frame, text = "登入", command = self.login).grid(row = 4, column = 1)
        tk.Button(self.login_frame, text = "忘記密碼").grid(row = 4, column = 2)

    def login(self):
        if self.username_str_var.get() == username and self.password_str_var.get() == password:
            print("登錄成功")
            # 成功之後到第二個頁面
            self.login_frame.destroy()  # 將登錄頁面清空
            #要進入第二頁
            MainPage(self.root)
        else:
            print("檢查帳號密碼")

class AboutFrame(tk.Frame):
    def __init__(self, root_2):
        super().__init__(master = root_2)
        tk.Label(self, text="2021/07/16").grid(row=0, column=0)

class MainPage():
    def __init__(self, root_2):
        #創建一個視窗
        self.root = root_2
        self.root.title("成績管理系統")
        #視窗大小
        self.root.geometry('600x400')

        self.frame = tk.Frame(self.root)
        self.frame.pack()

        self.insert_frame = tk.Frame(self.root)
        self.search_frame = tk.Frame(self.root)
        self.delete_frame = tk.Frame(self.root)
        self.change_frame = tk.Frame(self.root)
        self.about_frame = AboutFrame(self.root)

        self.about_frame.pack()

        #選項欄
        menu = tk.Menu(self.frame)

        menu.add_command(label = "登入", command = self.insert)
        menu.add_command(label = "查詢", command = self.search)
        menu.add_command(label = "刪除", command = self.delete)
        menu.add_command(label = "修改", command = self.change)
        menu.add_command(label = "關於", command = self.about)
        self.root['menu'] = menu

    def insert(self):
        print("登錄")

    def delete(self):
        print("刪除")

    def change(self):
        print("修改")

    def search(self):
        print("查詢")

    def about(self):
        print("關於")

        # self.username_str_var = tk.StringVar()
        # self.password_str_var = tk.StringVar()
        #
        # #一個頁面
        # self.login_frame = tk.Frame()
        #
        # self.login_frame.pack()#設置到頁面
        # #排版
        # tk.Label(self.login_frame).grid(row = 0, column = 0)
        # tk.Label(self.login_frame, text = "帳號: ").grid(row = 1, column = 1)
        # tk.Entry(self.login_frame, textvariable = self.username_str_var).grid(row = 1, column = 2)#輸入框
        # tk.Label(self.login_frame, text = "密碼: ").grid(row = 2, column =1)
        # tk.Entry(self.login_frame, textvariable = self.password_str_var).grid(row = 2, column = 2)#輸入框
        # tk.Label(self.login_frame).grid(row = 3, column = 3)
        #
        #
        #
        # #按下登錄，獲取用戶訊息，進行驗證
        # tk.Button(self.login_frame, text = "登入", command = self.login).grid(row = 4, column = 1)
        # tk.Button(self.login_frame, text = "忘記密碼").grid(row = 4, column = 2)

#創建視窗
root = tk.Tk()
#登錄頁面
# LoginPage(root)
MainPage(root)
#顯示視窗
root.mainloop()
