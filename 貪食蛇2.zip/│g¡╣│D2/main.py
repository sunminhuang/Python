import pygame
import random
import copy
import sys

def show_text(screen, pos, text, color, font_bold = False, font_size = 60, font_italic = False):
    #獲取字體 並設置大小
    cur_font = pygame.font.SysFont("A", font_size)
    #設定是否粗體
    cur_font.set_bold(font_bold)
    #設定是否斜體
    cur_font.set_italic(font_italic)
    #設置文字內容
    text_fmt = cur_font.render(text, 1, color)
    #產生文字
    screen.blit(text_fmt, pos)




scores = 0
#初始化蛇移動的位置
move_up = False
move_down = False
move_left = False
move_right = True

# 1-1 遊戲初始化
pygame.init()
clock = pygame.time.Clock() #捨至遊戲時鐘 幀率 fps
pygame.display.set_caption("貪食蛇2")
screen = pygame.display.set_mode((500, 500)) #視窗大小

#隨機產生食物位置
x = random.randint(10,490)
y = random.randint(10,490)
food_point = [x,y]

# 蛇
snake_list = [[10,10]]

# 1-2 啟動遊戲
running = False
while True:
    # 1-3 設置幀率
    clock.tick(20) # 1秒刷新20次
    # 1-4 視窗背景顏色
    screen.fill([255,255,255])

    food_rect = pygame.draw.circle(screen,[255,0,0],food_point,15,0)

    snake_rect = []#蛇身體在頁面上
    for pos in snake_list:
        snake_rect.append(pygame.draw.circle(screen, [255, 0, 0], pos, 5, 0))
        #只要蛇碰到食物就吃掉 並產生新食物
        if food_rect.collidepoint(pos):
            snake_list.append(food_point)
            scores += 1
            #產生食物
            food_point = [random.randint(10,490),random.randint(10,490)]
            food_rect = pygame.draw.circle(screen,[255,0,0],food_point,15,0)
            break


    #移動蛇的位置

    #先走一夏身體
    pos = len(snake_list) - 1
    while pos > 0:
        snake_list[pos] = copy.deepcopy(snake_list[pos-1])
        pos -= 1

    #pos = 0 #蛇的頭部
    if move_right:#右
        #x+=10一直往右走
        snake_list[pos][0] += 10
        if snake_list[pos][0] > 500:
            snake_list[pos][0] = 10

    if move_left:#左
        snake_list[pos][0] -= 10
        if snake_list[pos][0] < 0:
            snake_list[pos][0] = 500

    if move_up:#上
        snake_list[pos][1] -= 10
        if snake_list[pos][1] <= 0:
            snake_list[pos][1] = 500

    if move_down:#下
        snake_list[pos][1] += 10
        if snake_list[pos][1] > 500:
            snake_list[pos][1] = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:  # 離開遊戲
            sys.exit()  # 直接結束
        #判斷上下左右按鍵
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                move_up = True
                move_down = False
                move_left = False
                move_right = False
            if event.key == pygame.K_DOWN:
                move_down = True
                move_up = False
                move_left = False
                move_right = False
            if event.key == pygame.K_RIGHT:
                move_right = True
                move_left = False
                move_up = False
                move_down = False
            if event.key == pygame.K_LEFT:
                move_left = True
                move_right = False
                move_up = False
                move_down = False

    #蛇碰到自己 死亡
    heand_rect = snake_rect[0]
    count = len(snake_rect)
    while count > 1:
        if heand_rect.colliderect(snake_rect[count-1]):
            running = True
        count -= 1
    if running:
        show_text(screen, (20, 30), 'You dead!', (227, 29, 18), False, 100)
        show_text(screen, (20, 35), 'press space to try again', (0, 0, 22), False, 30)

    show_text(screen, (10, 10), 'Scores:' + str(scores), (100, 223, 223))
    #將內容顯示到介面
    pygame.display.update()



