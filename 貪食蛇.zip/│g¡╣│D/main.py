import pygame
import sys
import random

#全局定義
SCREEN_X = 600
SCREEN_Y = 600

#面相對象

#蛇
#25為一單位
class Sanke(object):#創建一個蛇的類
    #屬性: 1.初始化長度
    #   2.頭 方向
    def __init__(self): #初始化方法__init__
        self.dirction = pygame.K_RIGHT #默認方向朝右
        self.body = [] #身體

        for x in range(5):
            self.addnode()
    #方法:
    # 1.吃
    # 2.死亡
    # 3.移動
    # 4.方向
    def addnode(self):
        left, top = (0,0)
        if self.body: #先判斷有沒有身體
            left, top = (self.body[0].left, self.body[0].top)
        node = pygame.Rect(left, top, 25, 25)
        #判斷當前方向 移動
        if self.dirction == pygame.K_LEFT:#如果朝左
            node.left -= 25 #左右-25 向左
            # if node.left < 0:
            #     node.left = 600
        elif self.dirction == pygame.K_RIGHT:#如果朝右
            node.left += 25 #左右+25 向右
            # if node.left >= 600:
            #     node.left = 0
        elif self.dirction == pygame.K_UP:#如果朝上
            node.top -= 25 #向上
            # if node.top < 0:
            #     node.top = 600
        elif self.dirction == pygame.K_DOWN:#如果朝下
            node.top += 25 #向下
            # if node.top >= 600:
            #     node.top = 0
        self.body.insert(0, node)

    # 移動 刪除原本位置的身體
    def delnode(self):
        self.body.pop()

    #死亡判斷
    def isdead(self):
        # 撞牆 頭碰到邊界
        if self.body[0].x not in range(SCREEN_X):
            return True
        if self.body[0].y not in range(SCREEN_Y):
            return True
        #碰到自己
        if self.body[0] in self.body[1:]:
            return True
        return False
    #移動
    def move(self):
        self.addnode()
        self.delnode()

    #改變方向
    def changedirection(self,curkey):
        #如果處於直向就只能選左右
        LR = [pygame.K_LEFT, pygame.K_RIGHT] #左右
        # 如果處於橫向就只能選上下
        UD = [pygame.K_UP, pygame.K_DOWN] #上下
        if curkey in LR + UD:
            # 防止逆向改變
            if (curkey in LR) and (self.dirction in LR):
                return
            if (curkey in UD) and (self.dirction in UD):
                return
            self.dirction = curkey

#食物
class Food:
    def __init__(self):#初始位置
        self.rect = pygame.Rect(-25,0,25,25)
    def remove(self): #被吃掉
        self.rect.x = -25
    def set(self):#隨機放置
        if self.rect.x == -25:
            allpos = []
            #不能太靠牆 25～SCREEN_X-25 之間
            for pos in range(25,SCREEN_X - 25, 25):
                allpos.append(pos)
            self.rect.left = random.choice(allpos)
            self.rect.top = random.choice(allpos)
            print(self.rect)

def show_text(screen, pos, text, color, font_bold = False, font_size = 60, font_italic = False):
    #獲取字體 並設置大小
    cur_font = pygame.font.SysFont("A", font_size)
    #設定是否粗體
    cur_font.set_bold(font_bold)
    #設定是否斜體
    cur_font.set_italic(font_italic)
    #設置文字內容
    text_fmt = cur_font.render(text, 1, color)
    #產生文字
    screen.blit(text_fmt, pos)

def main():
    #初始化
    pygame.init()
    screen_size = (SCREEN_X,SCREEN_Y)
    screen = pygame.display.set_mode(screen_size)
    pygame.display.set_caption("貪食蛇")#視窗標題
    clock = pygame.time.Clock()
    scores = 0
    isdead = False

    snake = Sanke() #創建一條蛇
    food = Food() #創建食物

    fps = 10
    lev = 1

    while True:
        for event in pygame.event.get(): #從當前遊戲事件獲取內容
            #判斷事件
            if event.type == pygame.QUIT: #離開遊戲
                sys.exit() #直接結束
            #移動事件
            if event.type == pygame.KEYDOWN: #按鍵盤下鍵
                # 蛇進行移動 執行 changedirection 執行改變方向
                snake.changedirection(event.key)#跟據我輸入的key
                #如果死亡
                if event.key == pygame.K_SPACE and isdead:
                    #按空格 而且沒有死亡才可重新玩
                    return main() #重新玩

        # if lev == 1:
        #     screen.fill((255,255,255))
        # if lev == 2:
        #     screen.fill((255, 200, 100))
        screen.fill((255, 255, 255))
        #製作蛇的身體
        if not isdead:
            snake.move()
        if scores > 30:
            R = random.randint(0,255)
            G = random.randint(0,255)
            B = random.randint(0,255)
            for rect in snake.body:
                pygame.draw.rect(screen,(R,G,B), rect,0)
        else:
            for rect in snake.body:
                pygame.draw.rect(screen,(107,142,35),rect,0)

        #顯示死亡文字
        isdead = snake.isdead()

        if isdead:
            show_text(screen, (120,200), 'You dead!', (227,29,18), False, 100)
            show_text(screen, (170, 260), 'press space to try again', (0,0,22), False , 30)

        #食物處理 蛇頭與實務重疊 吃到 分數+1 蛇 長度+1個方塊
        for body_food in snake.body:
            if food.rect == body_food:
                scores += 1
                food.remove() #食物刪除
                snake.addnode() #蛇常+1
                break

        food.set()
        #食物重新放置
        pygame.draw.rect(screen, (255, 0, 0),food.rect,0)

        #顯示分數
        show_text(screen, (10,10),'Scores:' + str(scores), (100,223,223))
        # show_text(screen,(10,50),"lev " + str(lev),(60,78,223))
        pygame.display.update()#更新
        # if scores <= 10:
        #     fps = 10
        #     lev = 1
        # elif scores <= 20 and scores > 10:
        #     fps = 15
        #     lev = 2
        # elif scores > 30 and scores > 20:
        #     fps = 18

        clock.tick(fps)

main()